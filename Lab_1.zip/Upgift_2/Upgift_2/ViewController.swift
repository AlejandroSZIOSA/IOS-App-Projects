//
//  ViewController.swift
//  Upgift_2
//
//  Created by gabriel Sazo on 2022-08-31.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var texInputName: UITextField!
    @IBOutlet var textInputAge: UITextField!
    @IBOutlet var textInputEpost: UITextField!
    
    @IBOutlet var viewBox: UIView!
    
    
    var passed : Bool? // security best practices 
    let aceptedUserName = "test"
    let aceptedUserAge = "age"
    let aceptedUserEpost = "@Phoenix"
    
    let mySegue = "mySegue" // best practice
    
    var userName : String? = "" //security
    var userAge : String? = "" //security
    var userEpost : String? = "" //security
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    func checkValues(name:String, age:String) -> Bool{
        if (aceptedUserName == name) && (aceptedUserAge == age)  {
            return true
        }else { return false}
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // check secondViewController
        if segue.identifier == "mySegue" {
            let destinationVC = segue.destination as! SecondViewController
                if checkValues(name:userName!, age: userAge!){
                destinationVC.receivingMessage = "Passed"
                }else {destinationVC.receivingMessage = "Not passed"}
        }
    }
    /*Tap gesture recognize : recognize when click on something
    It is work with sender: UITapGestureRecognizer
    */
    @IBAction func onTap2(_ sender: UITapGestureRecognizer) {
        print("Welcome Animations")
    }
    @IBAction func onDrag(_ sender: UIPanGestureRecognizer) {
        //advanced
        //how much have been dragit
        let transaction = sender.translation(in: self.view)
        
        // create a variable that returns true and run something in this case a position on the screen
        if let viewToPan = sender.view {
            // viewToPan.center = CGPoint(x: 100.0,y: 100.0) // this works!
            //center.x = actually position on the screen
            //transactions = when x axe is moving
            viewToPan.center = CGPoint(x: viewToPan.center.x + transaction.x, y: viewToPan.center.y + transaction.y)
            
            //intercect = over
            // frame = CGRect
            if viewBox.frame.intersects(viewToPan.frame){
                print("Bingo")
                userName = texInputName.text
                userAge = textInputAge.text
            
                sender.state = .ended // sending final signal
                
                performSegue(withIdentifier: mySegue, sender: self)
                
            }else {print("Not Bingo")}
        }
        // do not miss the transaction
        sender.setTranslation(CGPoint.zero, in: self.view)
    }
}

