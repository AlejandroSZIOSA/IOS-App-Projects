//
//  SecondViewController.swift
//  Upgift_2
//
//  Created by gabriel Sazo on 2022-08-31.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet var imgResult: UIImageView!
    @IBOutlet var lblResult: UILabel!
    
    var receivingMessage: String?
    //let imgPassed = Any(named: "Upgift2_3.png")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //print(imgPassed)
        
        //optinal data :)
        lblResult.text = receivingMessage ?? "No data"
        
        if receivingMessage == "Passed" {
            imgResult.image = UIImage(named: "Upgift2_2.png")
            //print("yes")
        }else {
                imgResult.image = UIImage(named: "Upgift2_3.png")}
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
