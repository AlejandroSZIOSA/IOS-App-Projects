//
//  Persistence.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//
/*
 ***********  CORE DATA **************
 
 -CORE DATA STACK
 
 NS_PERSISTENT_CONTAINER / NS_MANAGED_OBJECT_MODEL / NS_MANAGED_OBJECT_CONTEXT
 / NS_PERSIST_STORE_COORDINATOR / STORAGE(SQLITE)
 
 -DATA STORAGE
 
 XML / BINARY / SQLITE / IN - MEMORY
 */

import CoreData
//* USING DEFAULT CORE DATA PROJECT TEMPLATE

struct PersistenceController{
    // -1. PERSISTENCE CONTROLLER
    static let shared = PersistenceController() // singleton
    
    // -2.PERSISTENCE CONTAINER
    let container: NSPersistentContainer

    // -3. INITIALIZATION (LOAD THE PERSISTENT STORAGE)
    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "MotivationApp")
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        container.viewContext.automaticallyMergesChangesFromParent = true
    }
    // PREVIEW TEST
    static var preview: PersistenceController = {
        let result = PersistenceController(inMemory: true)
        let viewContext = result.container.viewContext
        
        // SAMPLE DATA Testing :)
        for i in 0..<5 {
            let newItem = Item(context: viewContext)
            newItem.timestamp = Date()
            newItem.bookname = "Book name: \(i)"
            newItem.category = "Category"
            newItem.pagebook = "999"
            newItem.startlinebook = "23"
        }
        // SAVE IN MEMORY STORE
        do {
            try viewContext.save()
        } catch {
            
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
        return result // array
    }()
    
}
