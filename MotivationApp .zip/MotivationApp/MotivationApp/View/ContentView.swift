//
//  ContentView.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    //* PROPERTIES
    @State var bookName: String = ""
    @State var bookAuthor: String = ""
    @State var bookPage: String = ""
    @State var paragraphStartLine : String = ""
    @State var yourParagraph : String = "Test paragraph"
    @State var bookCategory: String = "Test Category"
    @State private var firstStartApp: Bool = true
    var categoryIn = "category"
    
    //TO - DO Inplement "NavigationPath"
    
    //* FETCHING CORE DATA IN RAM
    @Environment(\.managedObjectContext) private var viewContext
    
    //* LOAD CORE DATA
    
    //CREATE A CONECTION TO CORE DATA, IN THIS CASE ORDER BY TIME :)
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)],
        animation: .default)
    
    //* CATCH CORE DATA
    
    //CONTAIN THE FETCHED CORE DATA IN AN ARRAY OBJECT FORM
    private var items: FetchedResults<Item>
    
    //* FUNCTIONS
    public func showBookInformation(){
        let randomParagraph = items.randomElement()
        bookName = randomParagraph?.bookname ?? "no info"
        bookAuthor = randomParagraph?.author ?? "no info"
        bookPage = randomParagraph?.pagebook ?? "no info"
        paragraphStartLine = randomParagraph?.startlinebook ?? "no info"
        bookCategory = randomParagraph?.category ?? "no info"
        yourParagraph = randomParagraph?.paragraph ?? "no info"
    }
    //* VIEWS
    var body: some View {
        NavigationView {
            mainView // Conecting with other VIEW
            .navigationTitle (Text("Paragraph Catcher"))
            .background(Color.gray)
            .toolbar{
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink(destination: AddView(), label:{
                        Image(systemName: "plus")
                        } )
                }//TOOLBARITEM
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink(destination: DeleteView(), label:{
                        Text("Delete")
                        } )
                }//TOOLBARITEM
                ToolbarItem(placement: .bottomBar){
                    //sending parameters to other view :) by binding
                    NavigationLink(destination: ShowDetails(bookName:$bookName,bookAuthor: $bookAuthor, bookPage:$bookPage, pagraphStartLine:$paragraphStartLine ),label:{
                        Text("¶ Source")
                            .background(Color.black)
                            .foregroundColor(.cyan)
                            .font(.system(size: 25))
                            .cornerRadius(12)
                        } )
                }//TOOLBARITEM
            }//TOOLBAR
        }// NAVIGATIONVIEW
    }//VIEW
    var mainView: some View{
        ZStack{
            Color.gray
            VStack{
                HStack(alignment: .top){
                    Button("¶"){showBookInformation()}
                        .padding(19)
                        .background(Color.black)
                        .border(Color.purple, width: 5)
                        .foregroundColor(.cyan)
                        .font(.system(size: 20))
                        .cornerRadius(10)
                    Text(bookCategory)
                        .font(Font.custom("Georgia", size: 35))
                        .frame(width: 328, height: 60, alignment: .center)
                        .background(Color.cyan)
                }
                VStack{
                    Text(yourParagraph)
                        //38
                        .font(Font.custom("Georgia", size: 38))
                        .multilineTextAlignment(.center)//multiline text
                        .frame(width: 387, height: 540, alignment: .center)
                        .background(Color.yellow)
                    }
                }
                // fixed the problem when app starts:)
                .onAppear(){
                    if firstStartApp{
                        firstStartApp = false
                        showBookInformation()// SHOWING A PICK A RANDOM PARAGRAPH
                    }
                }//automatic
        }// ZSTACK
    } //VIEW
}
//PREVIEW
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}

