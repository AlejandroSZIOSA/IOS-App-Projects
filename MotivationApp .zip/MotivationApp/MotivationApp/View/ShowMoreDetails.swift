//
//  ShowMoreDetails.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-28.
//

import SwiftUI

struct ShowMoreDetails: View {
    //* SOME VARIABLE DECLARATION
    let paragraph : String
    let author : String
    
    //* VIEWS
    var body: some View {
        ZStack{
        Color.yellow
            VStack(alignment: .center){
                Image(systemName: "book")
                    .resizable()
                    .frame(width: 45, height: 45, alignment: .center)
                    .foregroundColor(.accentColor)
                Text(author)
                    .font(.system(size: 28))
                Image(systemName: "paragraph")
                    .resizable()
                    .frame(width: 45, height: 45, alignment: .center)
                    .foregroundColor(.accentColor)
                VStack(alignment: .leading){
                    Text(paragraph)
                        .font(Font.custom("Georgia", size: 39))
                        .multilineTextAlignment(.center)
                }//VSTACK
            }//VSTACK
        }//ZSTACK
        .ignoresSafeArea()
    }//VIEW
}
struct ShowMoreDetails_Previews: PreviewProvider {
    static var previews: some View {
        ShowMoreDetails(paragraph: "paragraph", author: "author")
        //ShowMoreDetails(bookAuthor: .constant(""))
    
    }
}
