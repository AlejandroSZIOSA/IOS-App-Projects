//
//  DeleteView.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//

import SwiftUI
struct DeleteView: View {
    
    //* PROPERTIES
    @State private var searchingFor = ""
    
    //* FETCHING CORE DATA IN RAM
    @Environment(\.managedObjectContext) private var viewContext
    
    //*LOAD CORE DATA
    
    /*
     PROBLEM:  "FILTER AND SORT "CORE DATA" INFORMATION ON THE LIST"
     
     SOLUTION:
     
     1-USED A "NS_SORT_DESCRIPTOR" I USED this for sort the REQUEST by Date "descending"
     
     SWIFT DEFINITION:An array of sort descriptors that define the sort order of the fetched results.
     
     2-USED A FETCH REQUEST BASED ON A "PREDICATE" for search values inside the DB. This get access to
     filter the REQUEST by a KeyWord.
     Fix SeachBar Problem!
     
     SWIFT DEFINITION: PREDICATE is An instance that defines logical conditions used to filter the fetched results.
     */
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Item.timestamp, ascending: false)], predicate: nil, animation: .default)
    
    
    //* CATCH DATA FROM CORE DATA
    // ADDING FETCH REQUEST INFORMATION IN AN ARRAY MED OBJECTS
    public var items: FetchedResults<Item>
    
    //* FUNCTIONS
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach(viewContext.delete)
            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
    // * VIEWS
    var body: some View {
        ZStack{
            VStack{
                Text("<- Delete + Show Info")
                    .font(.system(size: 22))
                    .bold()
                    .padding(1)
                    paragraphList
            }//VSTACK
            .navigationTitle(Text("Search By Book Title "))
            .navigationBarTitleDisplayMode(.inline) // Fix problem out space :)
        }.background(.gray)
        
    }//VIEW
    var paragraphList: some View{
        List {
            ForEach(items) { item in
                VStack(alignment: .leading){
                    NavigationLink{
                        //Passing parameters to another View
                        ShowMoreDetails(paragraph: item.paragraph ?? "", author: item.author ?? "" )
                        }label: {
                        Image(systemName: "book")
                        .foregroundColor(.accentColor)
                            Text("\(item.bookname ?? "")")
                                .font(.system(size: 15))
                                .bold()
                            }
                            HStack(alignment: .center, spacing: 9){
                                Text("Page: \(item.pagebook ?? "")")
                                    .font(.system(size: 16))
                                Text("Start-Line: \(item.startlinebook ?? "")")
                                    .font(.system(size: 16))
                                Text("Stored:\(item.timestamp!, formatter: itemFormatter)")
                                    .font(.system(size: 16))
                                    .foregroundColor(.gray)
                            }//HSTACK
                    }//VSTACK
                    .padding()
                    .background(.yellow)
                    .frame(width: 330, height: 55, alignment: .center)
                    .cornerRadius(20)
                }//FOREACH
                .onDelete(perform: deleteItems)
            }//LIST
            .searchable(text: $searchingFor ,prompt: Text("book Title"))
            //Defines logical conditions used to filter the fetched results.
            //USING KEYWORD "bookname"
            .onChange(of: searchingFor){
                    value in if !value.isEmpty{
                    //Here can change key word you whant look for "bookname " :)
                        items.nsPredicate = NSPredicate(format : "bookname CONTAINS[dc] %@", value)
                            } else{
                                items.nsPredicate = nil
                                }
                    }//ONCHANGE
    }// VIEW
}
struct DeleteView_Previews: PreviewProvider {
    static var previews: some View {
        //DeleteView()
        DeleteView().environment(\.managedObjectContext,PersistenceController.preview.container.viewContext)
    }
}
