//
//  AddView.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//

import SwiftUI
// Using On focus

// * DECLARE SOME REFERENCES ENUM (WORKING ON ONFOCUS)
///
///`Hashable` protocol. The
/// components used for hashing must be the same as the components compared
/// in your type's `==` operator implementation.
enum FocusBook: Hashable{
    case bookAuthor
    case bookName
    case paragraphExtract
    //case bookCategory
    case bookPage
    case startLine
}

struct AddView: View {
    //* PROPERTIES
    // References state to Focus :)
    /// The current state value, taking into account whatever bindings might be
    /// in effect due to the current location of focus.
    @FocusState var focusBookName: FocusBook?
    @FocusState var focusBookAuthor: FocusBook?
    @FocusState var focusBookParagraph: FocusBook?
    @FocusState var focusBookPage: FocusBook?
    @FocusState var focusStartLine: FocusBook?
    
    //* STATES
    @State var authorInput: String = ""
    @State var bookNameInput: String = ""
    @State var pageInput: String = ""
    @State var startLineInput: String = ""
    @State var paragraphInput: String = ""
    
    //Maximun Character counter
    //213
    @State var characterCounter : Int = 220
    private let maxCharacters = 220
    
    //PICKER ATRIBUTES
    @State private var selectedCategory : String = "Select Category"
    let listCategories: [String] = ["Soul", "Social", "Economy"]
    
    //* FETCHING CORE DATA IN RAM
    @Environment(\.managedObjectContext) private var viewContext
    
    //Button will be active when all field are fullfill
    private var isButtonDisabled: Bool{
        if(authorInput.isEmpty || bookNameInput.isEmpty || (selectedCategory == "Select Category") || paragraphInput.isEmpty || pageInput.isEmpty || startLineInput.isEmpty) {
            return true
        }
        else {return false}
    }
    //*FUNCTIONS
    
    // Clear text input
    private func clearAllTextInputs(){
        authorInput = ""
        bookNameInput = ""
        paragraphInput = ""
        selectedCategory = "Select Category"
        pageInput = ""
        startLineInput = ""
        //hideKeyboard()
    }
    //ADD Entity to DB
    private func addItem() {
        withAnimation {
            let newItem = Item(context: viewContext)
            newItem.timestamp = Date() // ordenar la lista
            newItem.bookname = bookNameInput //testing
            newItem.author = authorInput //testing
            newItem.id = UUID()
            newItem.paragraph = paragraphInput
            newItem.category = selectedCategory
            newItem.pagebook = pageInput
            newItem.startlinebook = startLineInput
            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
        //hideKeyboard() // calling extension :)
        clearAllTextInputs()
    }
    
    //* VIEWS
    var body: some View {
        ZStack{
            Color.gray
            VStack{
                HStack{
                    Text("+ Add ¶ Book Source")
                        .font(.system(size: 25))
                        .bold()
                }//VSTACK
                VStack(spacing: 8){
                    TextField("Author Name", text: $authorInput)
                        .padding()
                        .background(focusBookAuthor == .bookAuthor ? Color.cyan : .white)
                        .focused($focusBookAuthor, equals: .bookAuthor)
                        .cornerRadius(10)
                        .disableAutocorrection(true)
                    TextField("Book Name", text: $bookNameInput)
                        .padding()
                        .background(focusBookName == .bookName ? Color.cyan : .white)
                        .focused($focusBookName, equals: .bookName)
                        .cornerRadius(10)
                        .disableAutocorrection(true)
                    VStack{
                        //A PICKER
                        Text(selectedCategory)
                        Picker("Categories: ",selection: $selectedCategory){
                                ForEach(listCategories, id: \.self) {value
                                    in Text(value)
                                }
                            }
                            .background(Color.cyan)
                            .pickerStyle(.segmented)
                    }//VSTACK
                    HStack(spacing: 100){
                            TextField("Page", text: $pageInput)
                                .padding(10)
                                .background(focusBookPage == .bookPage ? Color.cyan : .white)
                                .focused($focusBookPage, equals: .bookPage)
                                .cornerRadius(10)
                                // Setting MAX leng of the TextInput
                                .onChange(of: pageInput){ value in
                                if value.count > 3 {
                                    pageInput = String(value.prefix(3))
                                    }
                                }
                            TextField("Start-Line", text: $startLineInput)
                                .padding(10)
                                .background(focusStartLine == .startLine ? Color.cyan : .white)
                                .focused($focusStartLine, equals: .startLine)
                                .cornerRadius(10)
                                // Setting max leng of the Text input
                                .onChange(of: startLineInput){ value in
                                    if value.count > 2 {
                                    startLineInput = String(value.prefix(2))
                                    }
                                }
                    }//HSTACK
                    .frame(width: 300, alignment: .center)
                    VStack{
                        Text("Write Some Paragraph Here")
                            .bold()
                        paragraphTextEditorView
                        Text("Characters Counter : \(characterCounter)")
                            .bold()
                    }//VSTACK
                }//VSTACK
            VStack{
                Button(action: {addItem()}, label: {
                    Spacer()
                    Text("Save")
                    Spacer()
                    }
                )//BUTTOM
                    .disabled(isButtonDisabled) // disable buttom
                    .padding()
                    .font(.headline)
                    //Ternary operation :)
                    .foregroundColor(isButtonDisabled ? Color.white : Color.cyan )
                    .background(Color.black)
                    .opacity(isButtonDisabled ?  0.3 : 1.0)
                }//VSTACK
                .frame(width: 100, height: 50)
                .cornerRadius(10)
           }//VSTACK
        }//ZSTACK
        .ignoresSafeArea()
    }//VIEW
    var paragraphTextEditorView : some View{
        TextEditor(text:$paragraphInput)
            .font(.system(size: 23))
            .multilineTextAlignment(.leading)
            .lineSpacing(10)
            .background(Color.yellow)
            .disableAutocorrection(true)
            .frame(width: 370, height: 250, alignment: .topLeading)
            .onChange(of: paragraphInput){ value in
            // Set max leng of the Text input :)
                characterCounter = value.count - maxCharacters
                if value.count > maxCharacters{
                    paragraphInput = String(value.prefix(maxCharacters))
                }
            }//ONCHANGE
    }//VIEW
}
struct AddView_Previews: PreviewProvider {
    static var previews: some View {
        //1 .AddView()
        AddView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
