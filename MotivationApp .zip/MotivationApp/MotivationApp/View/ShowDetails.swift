//
//  ShowDetails.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-27.
//
import SwiftUI
struct ShowDetails: View {
    
    //*PROPERTIES
    @Binding var bookName : String
    @Binding var bookAuthor : String
    @Binding var bookPage : String
    @Binding var pagraphStartLine : String
    
    //*VIEWS
    var body: some View {
        ZStack(alignment: .center){
            Color.yellow
            VStack( alignment: .center, spacing: 15){
                    Image(systemName: "book")
                        //.scaledToFill()
                        .resizable()
                        .frame(width: 60, height: 60, alignment: .center)
                        .foregroundColor(.accentColor)
                    Text("Book Title")
                        .font(.system(size: 26))
                        .bold()
                    Text("[ \(bookName) ]")
                        //22
                        .font(.system(size: 22))
                        .multilineTextAlignment(.center)
                    Text("Author")
                        .font(.system(size: 26))
                        .bold()
                    Text("[ \(bookAuthor) ]")
                        .font(.system(size: 22))
                HStack{
                    Text("Page")
                        .font(.system(size: 26))
                        .bold()
                    Text("[ \(bookPage) ]")
                        .font(.system(size: 22))
                    }
                HStack{
                    Text("Start-Line")
                        .font(.system(size: 26))
                        .bold()
                    Text("[ \(pagraphStartLine) ]")
                        .font(.system(size: 22))
                }//HSTACK
            }//VSTACK
        }//ZSTACK
        .ignoresSafeArea()
        .navigationTitle(Text("¶ Source"))
        .navigationBarTitleDisplayMode(.large) // Fix NavigationBar out space
    }
}
struct ShowDetails_Previews: PreviewProvider {
    static var previews: some View {
        ShowDetails(bookName: .constant(""), bookAuthor: .constant(""),
                    bookPage: .constant(""), pagraphStartLine: .constant("")
        
        )
    }
}

