//
//  HideKeyboardExtension.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//

//import Foundation
//import UIKit
import SwiftUI

// HIDING THE KEYBOARD PROGRAMATLY
#if canImport(UIKit)
extension View {
    func hideKeyboard(){
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
#endif

// testing :)
extension String {
    var isInt: Bool {
        return Int(self) != nil
    }
}
