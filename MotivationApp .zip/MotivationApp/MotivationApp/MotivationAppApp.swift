//
//  MotivationAppApp.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//

import SwiftUI

@main
struct MotivationAppApp: App {
    let persistenceController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            ContentView() //testing
                //CREATING ACCESS FOR USE CORE DATA IN THE APP
                //NS_MANAGED_OBJECT IS USED FOR STORE INFORMATION IN THE DB
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
               
        }
    }
}
