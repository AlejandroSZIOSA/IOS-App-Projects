//
//  Constant.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//

import SwiftUI

//FORMATER
// ACCES EVERYHERE
let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    //formatter.timeStyle = .medium
    return formatter
}()

//UI
//UX
