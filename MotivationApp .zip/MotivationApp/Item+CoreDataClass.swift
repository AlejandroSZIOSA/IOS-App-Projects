//
//  Item+CoreDataClass.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}
