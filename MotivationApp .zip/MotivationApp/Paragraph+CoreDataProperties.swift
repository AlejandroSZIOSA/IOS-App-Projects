//
//  Paragraph+CoreDataProperties.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//
//

import Foundation
import CoreData


extension Paragraph {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Paragraph> {
        return NSFetchRequest<Paragraph>(entityName: "Paragraph")
    }

    @NSManaged public var timestamp: Date?
    @NSManaged public var author: String?
    @NSManaged public var bookname: String?
    @NSManaged public var page: Int32
    @NSManaged public var startLine: Int32
    @NSManaged public var id: UUID?
    @NSManaged public var completion: Bool

}

extension Paragraph : Identifiable {

}
