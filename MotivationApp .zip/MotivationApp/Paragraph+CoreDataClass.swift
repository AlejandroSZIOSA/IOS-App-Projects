//
//  Paragraph+CoreDataClass.swift
//  MotivationApp
//
//  Created by gabriel Sazo on 2022-10-25.
//
//

import Foundation
import CoreData

@objc(Paragraph)
public class Paragraph: NSManagedObject {

}
